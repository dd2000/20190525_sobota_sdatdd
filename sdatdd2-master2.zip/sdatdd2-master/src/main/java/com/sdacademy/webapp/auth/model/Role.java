package com.sdacademy.webapp.auth.model;

public enum Role {
    ADMIN,
    USER
}
