package com.sdacademy.webapp.auth.exception;

public class SdaException extends RuntimeException {

    public SdaException(final String msg) {
        super(msg);
    }
}
