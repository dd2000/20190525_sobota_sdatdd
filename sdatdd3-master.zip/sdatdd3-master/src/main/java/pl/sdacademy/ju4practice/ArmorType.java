package pl.sdacademy.ju4practice;

public enum ArmorType {
    WHITE,
    BLUE,
    PURPLE,
    GOLD
}
