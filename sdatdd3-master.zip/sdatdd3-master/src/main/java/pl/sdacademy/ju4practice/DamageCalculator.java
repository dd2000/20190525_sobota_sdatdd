package pl.sdacademy.ju4practice;

public class DamageCalculator {

}
