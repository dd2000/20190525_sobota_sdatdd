package pl.sdacademy.ju4practice;

public enum AmmoType {
    LIGHT,
    HEAVY,
    LASER,
    SHOTGUN
}
