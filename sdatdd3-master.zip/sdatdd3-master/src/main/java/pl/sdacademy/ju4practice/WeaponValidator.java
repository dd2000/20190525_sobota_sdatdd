package pl.sdacademy.ju4practice;

public class WeaponValidator {

    public boolean isValid(final Weapon weapon) {
        return true;
    }
}
